/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TableObject;

/**
 *
 * @author TripleB
 */
public class ScheduleStaff {
     public String id_staff,name_staff,class_id,subject_code,room_number,weekday,time,name_subject;
    public int row,columm,credit;
    public ScheduleStaff(String id_staff,String name_staff ,String class_id,String subject_code,String name_subject,int credit ,String room_number,String weekday,String time){
        this.id_staff=id_staff;
        this.name_staff=name_staff;
        this.class_id=class_id;
        this.subject_code=subject_code;
        this.name_subject=name_subject;
        this.credit=credit;
        this.room_number=room_number;
        this.weekday=weekday;
        this.time=time;
        
    }

    public String getId_staff() {
        return id_staff;
    }

    public void setId_staff(String id_staff) {
        this.id_staff = id_staff;
    }

    public String getName_staff() {
        return name_staff;
    }

    public void setName_staff(String name_staff) {
        this.name_staff = name_staff;
    }

    public String getClass_id() {
        return class_id;
    }

    public void setClass_id(String class_id) {
        this.class_id = class_id;
    }

    public String getSubject_code() {
        return subject_code;
    }

    public void setSubject_code(String subject_code) {
        this.subject_code = subject_code;
    }

    public String getRoom_number() {
        return room_number;
    }

    public void setRoom_number(String room_number) {
        this.room_number = room_number;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getName_subject() {
        return name_subject;
    }

    public void setName_subject(String name_subject) {
        this.name_subject = name_subject;
    }

    public int getCredit() {
        return credit;
    }

    public void setCredit(int credit) {
        this.credit = credit;
    }
    public int getRow(){
        if(time.equals("8 a.m")){
            return 0;
        }
        else if(time.equals("10 a.m")){
            return 3;
        }
        else if(time.equals("1 p.m")){
            return 6;
        }
        else{
            return 7;
        }
    }
    public int getColumm(){
        if(weekday.equals("Monday")){
            return 0;
        }
        else if(weekday.equals("Tuesday")){
            return 1;
        }
        else if(weekday.equals("Wednesday")){
            return 2;
        }
        else if(weekday.equals("Thursday")){
            return 3;
        }
        else if(weekday.equals("Friday")){
            return 4;
        }
        else if(weekday.equals("Saturday")){
            return 5;
        }
        else {
            return 6;
        }
        
    }

    public String getWeekday() {
        return weekday;
    }

    public void setWeekday(String weekday) {
        this.weekday = weekday;
    }
}
