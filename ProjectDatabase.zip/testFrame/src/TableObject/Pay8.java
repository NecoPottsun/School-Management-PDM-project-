/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TableObject;

/**
 *
 * @author TripleB
 */
public class Pay8 {
    public String roll_no;
    public int tuition_id,amount_per_credit,amount;
    
    public Pay8(String roll_no,int tuition_id,int amount_per_credit,int amount){
        this.roll_no=roll_no;
        this.tuition_id=tuition_id;
        this.amount_per_credit=amount_per_credit;
        this.amount=amount;
    }

    public String getRoll_no() {
        return roll_no;
    }

    public void setRoll_no(String roll_no) {
        this.roll_no = roll_no;
    }

    public int getTuition_id() {
        return tuition_id;
    }

    public void setTuition_id(int tuition_id) {
        this.tuition_id = tuition_id;
    }

    public int getAmount_per_credit() {
        return amount_per_credit;
    }

    public void setAmount_per_credit(int amount_per_credit) {
        this.amount_per_credit = amount_per_credit;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }
}
