/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TableObject;

import java.util.Date;



/**
 *
 * @author TripleB
 */
public class TuitionStudent {
    private String roll_no,name_student;
    public int Amount;
    public Date deadline;
    public boolean paid_or_unpaid;
    
    public TuitionStudent(String roll_no,String name_student,int Amount,Date deadline,boolean paid_or_unpaid){
        this.roll_no=roll_no;
        this.name_student=name_student;
        this.Amount=Amount;
        this.deadline=deadline;
        this.paid_or_unpaid=paid_or_unpaid;
    }

    public String getRoll_no() {
        return roll_no;
    }

    public void setRoll_no(String roll_no) {
        this.roll_no = roll_no;
    }

    public String getName_student() {
        return name_student;
    }

    public void setName_student(String name_student) {
        this.name_student = name_student;
    }

    public int getAmount() {
        return Amount;
    }

    public void setAmount(int Amount) {
        this.Amount = Amount;
    }

    

    public Date getDeadline() {
        return deadline;
    }

    public void setDeadline(Date deadline) {
        this.deadline = deadline;
    }

    public boolean isPaid_or_unpaid() {
        return paid_or_unpaid;
    }

    public void setPaid_or_unpaid(boolean paid_or_unpaid) {
        this.paid_or_unpaid = paid_or_unpaid;
    }
    
}
