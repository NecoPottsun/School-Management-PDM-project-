package testframe;

import TableObject.ListofClasses;
import TableObject.SalaryStaff;
import TableObject.ScheduleStaff;
import TableObject.ScheduleStudent;
import TableObject.Staff4;
import TableObject.Student1;
import TableObject.TuitionStudent;
import java.awt.Image;
import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author TripleB
 */
public class test extends javax.swing.JFrame {
    String tempTime="",tempDay="",tempClassId="",tempClassIdDrop="";
    
    String filename = null;
    byte[] persom_image=null;
    private ArrayList<ScheduleStudent> _studentSchedule = new ArrayList<>();
    private ArrayList<ScheduleStudent> _tempStudentSchedule = new ArrayList<>();
    private ArrayList<ScheduleStaff> _staffSchedule = new ArrayList<>();
    
    Object[][] name ={
                {null, null, "Ngoc", null, null, null, null},
                {null, null, null, "Dep", null, null, null},
                {null, null, null, null,"Principle Database Management A1_207", null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, "thanh", null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
                 };
    
    private String _idViewr ="";
    public String _idClient="";
    private String _passClient="";
    private boolean student_OR_teacher;
    /**
     * Creates new form test
     */
    public test() throws SQLException {
        
        initComponents();
        _adminPanel.remove(jPanel5);
        
        _salaryButton.setEnabled(false);
        _tuitionButton.setEnabled(false);
        
    }
    public test(String _idClient,String _passClient) throws SQLException {
        student_OR_teacher=false;
        this._idClient=_idClient;
        this._passClient=_passClient;
        initComponents();
     
        _adminPanel.remove(jPanel2);
        ArrayList<Student1> studentList =getUserList();
        for(int j=0;j<studentList.size();j++){
            if(studentList.get(j).getRoll_no().equals(_idClient)){
                student_OR_teacher=true;
                _tID.setText(studentList.get(j).getRoll_no());
                _tMajor.setText(studentList.get(j).getMajor());
                _tName.setText(studentList.get(j).getName_student());
                _tRole.setText("Student");
                _tSection.setText(studentList.get(j).getSection());
                _tSex.setText(studentList.get(j).getGender());
                _tUsername.setText(_idClient);
                _tPassword.setText(_passClient);
            }
        }
        if(student_OR_teacher){
        _salaryButton.setEnabled(false);
            
            show_schedule_table_for_student(tempDay, tempTime, tempClassId,"addSubject",_idClient);
        
        }
        else{
            _adminPanel.remove(jPanel4);
            _tuitionButton.setEnabled(false);
            ArrayList<Staff4> staffList =getStaffList();
            for(int j=0;j<staffList.size();j++){
              if(staffList.get(j).id_staff.equals(_idClient)){
                
                _tID.setText(staffList.get(j).getId_staff());
                _tName.setText(staffList.get(j).getName_staff());
                _tRole.setText("Teacher");
                _tSex.setText(staffList.get(j).getGender());
                _tMajor.setText(staffList.get(j).getSalary()+"");
                _tUsername.setText(_idClient);
                _tPassword.setText(_passClient);
                _salaryMajorLB.setText("Salary");
                _sectionLB.setEnabled(false);
                _tSection.setEnabled(false);
              }
            }
            
            
        }
    }
    public Connection getConnection(){
         Connection con;
        try{
            con = DriverManager.getConnection("jdbc:sqlserver://localhost:1434;databaseName=School_Management;user=sa;password=hancg0257");
            return con;
        }catch(Exception e){
            e.printStackTrace();
            return null;
        }
    }
    
    public ArrayList<Student1> getUserList(String query) throws SQLException{
        ArrayList<Student1> studentList = new ArrayList<>();
        
        ResultSet rs;
        try(Connection con = getConnection();java.sql.Statement st = con.createStatement(); ){
            
            rs= st.executeQuery(query);
            _textArea.setText(query);
            Student1 student;
            while(rs.next()){
                student = new Student1(rs.getString("roll_no"),rs.getString("major"),rs.getString("name_student"),rs.getString("gender"),rs.getString("section"));
                studentList.add(student);
            }
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return studentList;
    }
    public ArrayList<ScheduleStudent> getScheduleStudentList(String query) throws SQLException{
        ArrayList<ScheduleStudent> scheduleStudentList = new ArrayList<>();
        
        
        
        ResultSet rs;
        try(Connection con = getConnection();java.sql.Statement st = con.createStatement(); ){
            
            rs= st.executeQuery(query);
            _textArea.setText(query);
            ScheduleStudent s;
            while(rs.next()){
                s = new ScheduleStudent(rs.getString("roll_no"),rs.getString("name_student"),rs.getString("class_id"),rs.getString("subject_code"),rs.getString("name_subject"),rs.getInt("credit"),rs.getString("room_number"),rs.getString("weekday"),rs.getString("time"));
                scheduleStudentList.add(s);
            }
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return scheduleStudentList;
    }
    public ArrayList<ScheduleStaff> getScheduleStaffList(String query) throws SQLException{
        ArrayList<ScheduleStaff> scheduleStaffList = new ArrayList<>();
        
        
        
        ResultSet rs;
        try(Connection con = getConnection();java.sql.Statement st = con.createStatement(); ){
            
            rs= st.executeQuery(query);
            _textArea.setText(query);
            ScheduleStaff s;
            while(rs.next()){
                s = new ScheduleStaff(rs.getString("id_staff"),rs.getString("name_staff"),rs.getString("class_id"),rs.getString("subject_code"),rs.getString("name_subject"),rs.getInt("credit"),rs.getString("room_number"),rs.getString("weekday"),rs.getString("time"));
                scheduleStaffList.add(s);
            }
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return scheduleStaffList;
    }
    public ArrayList<Staff4> getStaffList(String query) throws SQLException{
        ArrayList<Staff4> staffList = new ArrayList<>();
        
        
        
        ResultSet rs;
        try(Connection con = getConnection();java.sql.Statement st = con.createStatement(); ){
            
            rs= st.executeQuery(query);
            _textArea.setText(query);
            Staff4 s;
            while(rs.next()){
                s = new Staff4(rs.getString("id_staff"),rs.getString("name_staff"),rs.getString("gender"),rs.getInt("salary"));
                staffList.add(s);
            }
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return staffList;
    }
    public ArrayList<Staff4> getStaffList() throws SQLException{
        ArrayList<Staff4> staffList = new ArrayList<>();
        String query = "Select * from staff";
        
        
        ResultSet rs;
        try(Connection con = getConnection();java.sql.Statement st = con.createStatement(); ){
            
            rs= st.executeQuery(query);
            _textArea.setText(query);
            Staff4 s;
            while(rs.next()){
                s = new Staff4(rs.getString("id_staff"),rs.getString("name_staff"),rs.getString("gender"),rs.getInt("salary"));
                staffList.add(s);
            }
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return staffList;
    }
    public ArrayList<ListofClasses> getClassSystemList(String add) throws SQLException{
        ArrayList<ListofClasses> classSystemList = new ArrayList<>();
        String query = "SELECT A2.class_id, c.subject_code, c.name_subject, c.credit, A2.weekday, A2.time, A2.room_number,name_staff FROM Course c\n" +
"INNER JOIN (SELECT cl.class_id,cl.subject_code,cl.weekday,cl.time,cl.room_number,A1.name_staff FROM Classes cl,(SELECT t.class_id, s.name_staff FROM Teach t INNER JOIN Staff s ON t.id_staff = s.id_staff) AS A1 \n" +
"WHERE cl.class_id = A1.class_id) AS A2\n" +
"ON A2.subject_code = c.subject_code "+add;
        ResultSet rs;
        try(Connection con = getConnection();java.sql.Statement st = con.createStatement(); ){
            
            rs= st.executeQuery(query);
            _textArea.setText(query);
            ListofClasses l;
            while(rs.next()){
                l = new ListofClasses(rs.getString("class_id"),rs.getString("subject_code"),rs.getString("name_subject"),rs.getInt("credit"),rs.getString("weekday"),rs.getString("time"),rs.getString("room_number"),rs.getString("name_staff"));
                classSystemList.add(l);
            }
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return classSystemList;
    }
    public ArrayList<Student1> getUserList() throws SQLException{
        ArrayList<Student1> studentList = new ArrayList<>();
        
        String query = "Select * from Student";
        
        ResultSet rs;
        try(Connection con = getConnection();java.sql.Statement st = con.createStatement(); ){
            
            rs= st.executeQuery(query);
            _textArea.setText(query);
            Student1 student;
            while(rs.next()){
                student = new Student1(rs.getString("roll_no"),rs.getString("major"),rs.getString("name_student"),rs.getString("gender"),rs.getString("section"));
                studentList.add(student);
            }
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return studentList;
    }
    public ArrayList<SalaryStaff> getSalaryStaffList(String query) throws SQLException{
        ArrayList<SalaryStaff> salaryStaffList = new ArrayList<>();
        
        
        
        ResultSet rs;
        try(Connection con = getConnection();java.sql.Statement st = con.createStatement(); ){
            
            rs= st.executeQuery(query);
            _textArea.setText(query);
            SalaryStaff s;
            while(rs.next()){
                s = new SalaryStaff(rs.getString("id_staff"),rs.getString("name_staff"),rs.getInt("salary"));
                salaryStaffList.add(s);
            }
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return salaryStaffList;
    }
    public ArrayList<TuitionStudent> getTuitionStudentList(String query) throws SQLException{
        ArrayList<TuitionStudent> salaryStaffList = new ArrayList<>();
        
        ResultSet rs;
        try(Connection con = getConnection();java.sql.Statement st = con.createStatement(); ){
            
            rs= st.executeQuery(query);
            _textArea.setText(query);
            TuitionStudent t;
            while(rs.next()){
                t = new TuitionStudent(rs.getString("roll_no"),rs.getString("name_student"),rs.getInt("Amount"),rs.getDate("deadline_date"),rs.getBoolean("paid_or_unpaid"));
                salaryStaffList.add(t);
            }
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return salaryStaffList;
    }

    //Display Data in table
    public void show_user_in_jtable(String query,int type) throws SQLException{
        
        DefaultTableModel model = (DefaultTableModel) _tableInfo.getModel();
        model.setRowCount(0);
        if(type==0){
            ArrayList<Student1> list = getUserList(query);
            Object[] row = new Object[5];
            for(int i=0;i<list.size();i++){
            row[0] = list.get(i).getRoll_no();
            row[1] = list.get(i).getMajor();
            row[2] = list.get(i).getName_student();
            row[3] = list.get(i).getGender();
            row[4] = list.get(i).getSection();
            model.addRow(row);
        }
        }else{
             ArrayList<Staff4> list2 = getStaffList(query);
            Object[] row = new Object[3];
            for(int i=0;i<list2.size();i++){
            row[0] = list2.get(i).getId_staff();
            row[1] = list2.get(i).getName_staff();
            row[2] = list2.get(i).getGender();
            
            model.addRow(row);
        }
        System.out.println(_tableInfo.getRowCount());
        
                
    }
    }
    public void show_schedule_table_for_student(String day,String time,String class_id,String action,String ID) throws SQLException{
        DefaultTableModel model = (DefaultTableModel) _tableScheduleAD.getModel();
        model.setRowCount(0);
        if(action.equals("addSubject")){
            if(_tempStudentSchedule.size()>0){
            boolean loop=false;
            for(int i =0;i<_tempStudentSchedule.size();i++){
                if(_tempStudentSchedule.get(i).getWeekday().equals(day) && _tempStudentSchedule.get(i).equals(time)){
                       loop=true;
                       break;
                }
            }
            if(!loop){
                String query = "INSERT INTO Study VALUES ('"+ID+"','"+class_id+"')\n" +
                        "UPDATE Pay SET \n" +
                        "Amount = ( Amount_per_credit* (SELECT A2.Total_credit FROM Pay p INNER JOIN (\n" +
                        "SELECT s.roll_no, SUM(A1.credit) AS Total_credit FROM Study s, (SELECT c1.class_id,c2.subject_code,c2.credit FROM Classes c1,Course c2 WHERE c1.subject_code = c2.subject_code) AS A1 WHERE s.class_id = A1.class_id \n" +
                        "GROUP BY s.roll_no) \n" +
                        "AS A2 ON A2.roll_no = p.roll_no AND p.roll_no ='"+ID+"')\n" +
                        ")\n" +
                        "WHERE roll_no = '"+ID+"' ;\n" +
                        "UPDATE PAY SET \n" +
                        "Amount = 0 \n" +
                        "WHERE Amount IS NULL;";

                executeSQLquery(query,"Insert");
            }else{
                JOptionPane.showMessageDialog(null,"Trùng lịch rồi ku ơi");
                return;
            }
            }else{
                String query = "INSERT INTO Study VALUES ('"+ID+"','"+class_id+"')\n" +
                        "UPDATE Pay SET \n" +
                        "Amount = ( Amount_per_credit* (SELECT A2.Total_credit FROM Pay p INNER JOIN (\n" +
                        "SELECT s.roll_no, SUM(A1.credit) AS Total_credit FROM Study s, (SELECT c1.class_id,c2.subject_code,c2.credit FROM Classes c1,Course c2 WHERE c1.subject_code = c2.subject_code) AS A1 WHERE s.class_id = A1.class_id \n" +
                        "GROUP BY s.roll_no) \n" +
                        "AS A2 ON A2.roll_no = p.roll_no AND p.roll_no ='"+ID+"')\n" +
                        ")\n" +
                        "WHERE roll_no = '"+ID+"' ;\n" +
                        "UPDATE PAY SET \n" +
                        "Amount = 0 \n" +
                        "WHERE Amount IS NULL;";

                executeSQLquery(query,"Insert");
            }
        }else{
            String query="DELETE FROM Study WHERE roll_no = '"+ID+"' AND class_id ='"+class_id+"'" +
                        "UPDATE Pay SET \n" +
                        "Amount = ( Amount_per_credit* (SELECT A2.Total_credit FROM Pay p INNER JOIN (\n" +
                        "SELECT s.roll_no, SUM(A1.credit) AS Total_credit FROM Study s, (SELECT c1.class_id,c2.subject_code,c2.credit FROM Classes c1,Course c2 WHERE c1.subject_code = c2.subject_code) AS A1 WHERE s.class_id = A1.class_id \n" +
                        "GROUP BY s.roll_no) \n" +
                        "AS A2 ON A2.roll_no = p.roll_no AND p.roll_no ='"+ID+"')\n" +
                        ")\n" +
                        "WHERE roll_no = '"+ID+"' ;\n";
            executeSQLquery(query,"Delete");
        }
        String t="SELECT s.roll_no,s.name_student, classes.class_id, c.subject_code, c.name_subject, c.credit, classes.room_number, classes.weekday, classes.time\n" +
"FROM Student s, Course c, Classes classes , Study study\n" +
"WHERE s.roll_no = study.roll_no AND study.class_id = classes.class_id AND classes.subject_code = c.subject_code AND s.roll_no='"+ID+"'";
        ArrayList<ScheduleStudent> studentClasses = getScheduleStudentList(t);
        _tempStudentSchedule=studentClasses;
        Object[] row = new Object[4];
        for(int k=0;k<studentClasses.size();k++){
            row[0] = studentClasses.get(k).getClass_id();
            row[1] = studentClasses.get(k).getSubject_code();
            row[2] = studentClasses.get(k).getName_subject();
            row[3] = studentClasses.get(k).getCredit();
            model.addRow(row);
        }
    }
    //Execute the sql query
    public void executeSQLquery(String query , String message) throws SQLException{
        
         
        try(Connection con = getConnection();java.sql.Statement st = con.createStatement();){
            
            if((st.executeUpdate(query)) == 1){
                
                //refresh jtable  data
                _textArea.setText(query);
                
                JOptionPane.showMessageDialog(null,"Data "+message+" Successfully");
            }else{
                JOptionPane.showMessageDialog(null,"Data not "+message);
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        
        
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel4 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        _adminPanel = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        jTextField1 = new javax.swing.JTextField();
        _comboTables = new javax.swing.JComboBox<>();
        _selectTableButton = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        _textName = new javax.swing.JTextField();
        _clearButoon = new javax.swing.JButton();
        _searchButton = new javax.swing.JButton();
        _comboJob = new javax.swing.JComboBox<>();
        _comboSex = new javax.swing.JComboBox<>();
        _comboMajor = new javax.swing.JComboBox<>();
        _comboSection = new javax.swing.JComboBox<>();
        _textSelect = new javax.swing.JTextField();
        _selectButton = new javax.swing.JButton();
        _salaryButton = new javax.swing.JButton();
        _tuitionButton = new javax.swing.JButton();
        _scheduleButton = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        _tableInfo = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        _textIDTable = new javax.swing.JTextField();
        _textNameTable = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        _textRoleTable = new javax.swing.JTextField();
        jScrollPane3 = new javax.swing.JScrollPane();
        _tableSchedule = new javax.swing.JTable();
        jPanel5 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        _labelImage = new javax.swing.JLabel();
        _imageButton = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        _salaryMajorLB = new javax.swing.JLabel();
        _sectionLB = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        _textUserNameInfo = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();
        _textPasswordInfo = new javax.swing.JPasswordField();
        _textNewPasswordInfo = new javax.swing.JPasswordField();
        _tRole = new javax.swing.JTextField();
        _tName = new javax.swing.JTextField();
        _tUsername = new javax.swing.JTextField();
        _tID = new javax.swing.JTextField();
        _tSex = new javax.swing.JTextField();
        _tMajor = new javax.swing.JTextField();
        _tSection = new javax.swing.JTextField();
        _tPassword = new javax.swing.JPasswordField();
        panel1 = new java.awt.Panel();
        jScrollPane4 = new javax.swing.JScrollPane();
        _tableClassesAD = new javax.swing.JTable();
        jScrollPane5 = new javax.swing.JScrollPane();
        _tableScheduleAD = new javax.swing.JTable();
        jLabel9 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        _textNameSubjectAD = new javax.swing.JTextField();
        _dropADButton = new javax.swing.JButton();
        _filterButton = new javax.swing.JButton();
        _clearADButton = new javax.swing.JButton();
        _addADButton = new javax.swing.JButton();
        _comboNameMajorAD = new javax.swing.JComboBox<>();
        panel2 = new java.awt.Panel();
        jScrollPane6 = new javax.swing.JScrollPane();
        _textArea = new javax.swing.JTextArea();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(jTable1);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        jButton1.setText("jButton1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jTextField1.setText("Choose table to edit");

        _comboTables.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Courses", "Classes", "Staff", "Teach", "Student", "Study", "Tuition", "Pay" }));
        _comboTables.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                _comboTablesActionPerformed(evt);
            }
        });

        _selectTableButton.setText("Select");
        _selectTableButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                _selectTableButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(381, 381, 381)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(_selectTableButton)
                    .addComponent(_comboTables, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(435, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(116, 116, 116)
                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31)
                .addComponent(_comboTables, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(49, 49, 49)
                .addComponent(_selectTableButton)
                .addContainerGap(500, Short.MAX_VALUE))
        );

        _adminPanel.addTab("Admin", jPanel2);

        _clearButoon.setText("Clear");
        _clearButoon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                _clearButoonActionPerformed(evt);
            }
        });

        _searchButton.setText("Search");
        _searchButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                _searchButtonActionPerformed(evt);
            }
        });

        _comboJob.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Student", "Teacher", " ", " " }));

        _comboSex.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "None", "Male", "Female", " " }));

        _comboMajor.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "None", "BA", "IT", "EE", "BT" }));

        _comboSection.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "None", "K15", "K16", "K17", "K18", "K19", "K20", " " }));
        _comboSection.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                _comboSectionActionPerformed(evt);
            }
        });

        _textSelect.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                _textSelectActionPerformed(evt);
            }
        });

        _selectButton.setText("Select");
        _selectButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                _selectButtonActionPerformed(evt);
            }
        });

        _salaryButton.setText("Salary");
        _salaryButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                _salaryButtonActionPerformed(evt);
            }
        });

        _tuitionButton.setText("Tuition");
        _tuitionButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                _tuitionButtonActionPerformed(evt);
            }
        });

        _scheduleButton.setText("Schedule");
        _scheduleButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                _scheduleButtonActionPerformed(evt);
            }
        });

        jLabel1.setText("Name");

        _tableInfo.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Roll no", "Name Student", "Major", "Gender", "Section"
            }
        ));
        _tableInfo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _tableInfoMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(_tableInfo);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(_scheduleButton, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(215, 215, 215)
                        .addComponent(_salaryButton, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(185, 185, 185)
                        .addComponent(_tuitionButton, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 821, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addComponent(_comboJob, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(122, 122, 122)
                                    .addComponent(_comboSex, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(125, 125, 125)
                                    .addComponent(_comboMajor, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(27, 27, 27)
                                    .addComponent(_textName, javax.swing.GroupLayout.PREFERRED_SIZE, 575, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addComponent(_textSelect, javax.swing.GroupLayout.PREFERRED_SIZE, 700, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addGap(26, 26, 26)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(_comboSection, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addComponent(_clearButoon)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(_searchButton))))
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(_selectButton, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(8, 8, 8))))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(_textName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_clearButoon)
                    .addComponent(_searchButton)
                    .addComponent(jLabel1))
                .addGap(38, 38, 38)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(_comboJob, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_comboSex, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_comboMajor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_comboSection, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(49, 49, 49)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 40, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(_textSelect, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_selectButton))
                .addGap(27, 27, 27)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(_salaryButton, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_tuitionButton, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_scheduleButton, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        _adminPanel.addTab("Search", jPanel1);

        jLabel2.setText("ID:");

        jLabel3.setText("Name:");

        jLabel4.setText("Role:");

        _tableSchedule.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"
            }
        ));
        _tableSchedule.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _tableScheduleMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                _tableScheduleMouseEntered(evt);
            }
        });
        jScrollPane3.setViewportView(_tableSchedule);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane3)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(67, 67, 67)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE))
                .addGap(39, 39, 39)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(_textIDTable, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_textRoleTable, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_textNameTable, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(457, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(_textRoleTable, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(39, 39, 39)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(_textIDTable, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addGap(34, 34, 34)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(_textNameTable, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 32, Short.MAX_VALUE)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 229, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(349, 349, 349))
        );

        _adminPanel.addTab("Time table", jPanel3);

        jLabel5.setText("Role");

        jLabel6.setText("Name");

        jLabel7.setText("Username");

        jLabel8.setText("Password");

        _imageButton.setText("Browser");
        _imageButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                _imageButtonActionPerformed(evt);
            }
        });

        jLabel10.setText("ID");

        jLabel11.setText("Sex");

        _salaryMajorLB.setText("Major");

        _sectionLB.setText("Section");

        jLabel14.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel14.setText("Change your acount");

        jLabel15.setText("Your username");

        jLabel16.setText("Old password");

        jLabel17.setText("New password");

        jButton2.setText("Change");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        _tRole.setEditable(false);

        _tName.setEditable(false);

        _tUsername.setEditable(false);

        _tID.setEditable(false);

        _tSex.setEditable(false);
        _tSex.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                _tSexActionPerformed(evt);
            }
        });

        _tMajor.setEditable(false);
        _tMajor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                _tMajorActionPerformed(evt);
            }
        });

        _tSection.setEditable(false);

        _tPassword.setEditable(false);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jSeparator1)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addComponent(jLabel6)
                    .addComponent(jLabel7)
                    .addComponent(jLabel8)
                    .addComponent(jLabel10)
                    .addComponent(_sectionLB)
                    .addComponent(_salaryMajorLB)
                    .addComponent(jLabel11))
                .addGap(62, 62, 62)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(_tMajor)
                    .addComponent(_tSex, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(_tID)
                    .addComponent(_tRole, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(_tName, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(_tUsername, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(_tSection, javax.swing.GroupLayout.DEFAULT_SIZE, 400, Short.MAX_VALUE)
                    .addComponent(_tPassword))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(_labelImage, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(_imageButton, javax.swing.GroupLayout.DEFAULT_SIZE, 335, Short.MAX_VALUE))
                .addContainerGap())
            .addComponent(jLabel14, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel17, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(29, 29, 29)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(_textUserNameInfo)
                    .addComponent(_textPasswordInfo)
                    .addComponent(_textNewPasswordInfo, javax.swing.GroupLayout.DEFAULT_SIZE, 500, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 136, Short.MAX_VALUE)
                .addComponent(jButton2)
                .addGap(79, 79, 79))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(57, 57, 57)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(_tRole, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(32, 32, 32)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(_tName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(38, 38, 38)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(_tUsername, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(38, 38, 38)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(_tPassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(32, 32, 32)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel10)
                            .addComponent(_tID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(29, 29, 29)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel11)
                            .addComponent(_tSex, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(_labelImage, javax.swing.GroupLayout.PREFERRED_SIZE, 352, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(33, 33, 33)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(_salaryMajorLB)
                            .addComponent(_tMajor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(21, 21, 21)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(_sectionLB)
                            .addComponent(_tSection, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(_imageButton, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel14)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(41, 41, 41)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel15)
                            .addComponent(_textUserNameInfo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(36, 36, 36)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel16)
                            .addComponent(_textPasswordInfo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 58, Short.MAX_VALUE)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel17)
                            .addComponent(_textNewPasswordInfo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGap(26, 26, 26))
        );

        _adminPanel.addTab("Your info", jPanel5);

        _tableClassesAD.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Class ID", "Subject Code", "Name Subject", "Credit", "Weekday", "Time", "Room ", "Staff name"
            }
        ));
        _tableClassesAD.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _tableClassesADMouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(_tableClassesAD);

        _tableScheduleAD.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Class ID", "Subject Code", "Name Subject", "Credit"
            }
        ));
        _tableScheduleAD.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _tableScheduleADMouseClicked(evt);
            }
        });
        jScrollPane5.setViewportView(_tableScheduleAD);

        jLabel9.setText("Name subject");

        jLabel18.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel18.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel18.setText("List of your classes");

        jLabel19.setText("Name major");

        _dropADButton.setText("Drop");
        _dropADButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                _dropADButtonActionPerformed(evt);
            }
        });

        _filterButton.setText("Filter");
        _filterButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                _filterButtonActionPerformed(evt);
            }
        });

        _clearADButton.setText("Clear");
        _clearADButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                _clearADButtonActionPerformed(evt);
            }
        });

        _addADButton.setText("Add");
        _addADButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                _addADButtonActionPerformed(evt);
            }
        });

        _comboNameMajorAD.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "None", "BA-Business", "BT-Bio Technology", "IT-Computer Science & Engineering", "EE-Electrical Engineering", "CE-Civil Engineering", "ISE-Industrial Engineering & Management", "MA-Mathematics" }));

        javax.swing.GroupLayout panel1Layout = new javax.swing.GroupLayout(panel1);
        panel1.setLayout(panel1Layout);
        panel1Layout.setHorizontalGroup(
            panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane4)
            .addComponent(jScrollPane5)
            .addGroup(panel1Layout.createSequentialGroup()
                .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 380, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 372, Short.MAX_VALUE)
                .addComponent(_addADButton)
                .addGap(18, 18, 18)
                .addComponent(_dropADButton)
                .addGap(65, 65, 65))
            .addGroup(panel1Layout.createSequentialGroup()
                .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, 150, Short.MAX_VALUE)
                    .addComponent(jLabel19, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(30, 30, 30)
                .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(_textNameSubjectAD)
                    .addComponent(_comboNameMajorAD, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(60, 60, 60)
                .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(_filterButton)
                    .addComponent(_clearADButton))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panel1Layout.setVerticalGroup(
            panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panel1Layout.createSequentialGroup()
                        .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel9)
                            .addComponent(_textNameSubjectAD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(29, 29, 29)
                        .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel19)
                            .addComponent(_clearADButton)
                            .addComponent(_comboNameMajorAD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(_filterButton, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 36, Short.MAX_VALUE)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 370, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_addADButton)
                    .addComponent(_dropADButton))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        _adminPanel.addTab("Add/Drop Subject", panel1);

        _textArea.setColumns(20);
        _textArea.setRows(5);
        jScrollPane6.setViewportView(_textArea);

        javax.swing.GroupLayout panel2Layout = new javax.swing.GroupLayout(panel2);
        panel2.setLayout(panel2Layout);
        panel2Layout.setHorizontalGroup(
            panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane6, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 963, Short.MAX_VALUE)
        );
        panel2Layout.setVerticalGroup(
            panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel2Layout.createSequentialGroup()
                .addGap(165, 165, 165)
                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(212, Short.MAX_VALUE))
        );

        _adminPanel.addTab("Query", panel2);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(_adminPanel, javax.swing.GroupLayout.Alignment.TRAILING)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(_adminPanel, javax.swing.GroupLayout.Alignment.TRAILING)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void _comboSectionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event__comboSectionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event__comboSectionActionPerformed

    private void _selectTableButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event__selectTableButtonActionPerformed
        if(_comboTables.getSelectedIndex()==0){
            Courses c = new Courses();
            c.setVisible(true);
            this.setVisible(false);
        }
        if(_comboTables.getSelectedIndex()==1){
            Classes c = new Classes();
            c.setVisible(true);
            this.setVisible(false);
        }
        if(_comboTables.getSelectedIndex()==2){
            Staff t = new Staff();
            t.setVisible(true);
            this.setVisible(false);
        }
        if(_comboTables.getSelectedIndex()==3){
            Teach t = new Teach();
            t.setVisible(true);
            this.setVisible(false);
        }
        if(_comboTables.getSelectedIndex()==4){
            Student s = new Student();
            s.setVisible(true);
            this.setVisible(false);
        }
        if(_comboTables.getSelectedIndex()==5){
            Study s = new Study();
            s.setVisible(true);
            this.setVisible(false);
        }
        if(_comboTables.getSelectedIndex()==6){
            Tuition t = new Tuition();
            t.setVisible(true);
            this.setVisible(false);
        }
        if(_comboTables.getSelectedIndex()==7){
            Pay p = new Pay();
            p.setVisible(true);
            this.setVisible(false);
        }
    }//GEN-LAST:event__selectTableButtonActionPerformed

    private void _clearButoonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event__clearButoonActionPerformed
        _comboSex.setSelectedIndex(0);
        _comboMajor.setSelectedIndex(0);
        _comboJob.setSelectedIndex(0);
        _comboSection.setSelectedIndex(0);
        _textRoleTable.setText("");
        _textIDTable.setText("");
        _textNameTable.setText("");
        
        if(!_idClient.equals("")){
            if(student_OR_teacher){
            _tuitionButton.setEnabled(true);
            _salaryButton.setEnabled(false);
            DefaultTableModel model = (DefaultTableModel) _tableClassesAD.getModel();
            model.setRowCount(0);
            }else{
            _tuitionButton.setEnabled(false);
            _salaryButton.setEnabled(true);
            }
            
        }else{
            _tuitionButton.setEnabled(false);
            _salaryButton.setEnabled(false);
            
            DefaultTableModel model = (DefaultTableModel) _tableClassesAD.getModel();
            model.setRowCount(0);
            model = (DefaultTableModel) _tableScheduleAD.getModel();
            model.setRowCount(0);
        }
        if(student_OR_teacher || _idClient.equals("")){
            tempClassId="";tempClassIdDrop="";tempDay="";tempTime="";
            _tempStudentSchedule = new ArrayList<>();
        }
        _textName.setText("");
        _textSelect.setText("");
        _tableInfo.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                
            },
            new String [] {
                "Roll no", "Name Student", "Major", "Gender", "Section"
            }
        ));
        DefaultTableModel model = (DefaultTableModel) _tableInfo.getModel();
        model.setRowCount(0);
        _idViewr="";
        _tableSchedule.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"
            }
        ));
    }//GEN-LAST:event__clearButoonActionPerformed

    private void _searchButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event__searchButtonActionPerformed
        String sex,major,name;
        String[] arrayQuery = new String[10];
        int i=0;
        
        
        if(_comboJob.getSelectedIndex()==1){
        _tuitionButton.setEnabled(false);
        _salaryButton.setEnabled(true);
        _tableInfo.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                
            },
            new String [] {
                "Teacher_ID", "Name","Sex"
            }
        ));
        if(_comboSex.getSelectedIndex()!=0){
             sex = "gender='"+_comboSex.getItemAt(_comboSex.getSelectedIndex())+"'";
             arrayQuery[i]=sex;
             i++;
             
        } 
        if(!_textName.equals("")){
            name="name_staff like '%"+_textName.getText()+"%'";
            arrayQuery[i]=name;
            i++;
        }
        
        String query="Select * from Staff where  ";
        for(int j=0;j<i;j++){
            if(j==0){
                query+=arrayQuery[j];
            }else{
                query+=" and " + arrayQuery[j];
            }
        }
            //System.out.println(i);
           
            try {
                show_user_in_jtable(query,1);
            } catch (SQLException ex) {
                Logger.getLogger(test.class.getName()).log(Level.SEVERE, null, ex);
            }
        }else{
            _salaryButton.setEnabled(false);
            _tuitionButton.setEnabled(true);
            _tableInfo.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                
            },
            new String [] {
                "Roll no", "Name Student", "Major", "Gender", "Section"
            }
        ));
        if(_comboSex.getSelectedIndex()!=0){
             sex = "gender='"+_comboSex.getItemAt(_comboSex.getSelectedIndex())+"'";
             arrayQuery[i]=sex;
             i++;
             
        } 
        if(!_textName.equals("")){
            name="name_student like '%"+_textName.getText()+"%'";
            arrayQuery[i]=name;
            i++;
        }
        if(_comboMajor.getSelectedIndex()!=0){
             major="section='"+_comboMajor.getItemAt(_comboMajor.getSelectedIndex())+"'";
             arrayQuery[i]=major;
             i++;
        }  
        
        String query="Select * from Student where  ";
        for(int j=0;j<i;j++){
            if(j==0){
                query+=arrayQuery[j];
            }else{
                query+=" and " + arrayQuery[j];
            }
        }
            System.out.println(i);
           
            try {
                show_user_in_jtable(query,0);
            } catch (SQLException ex) {
                Logger.getLogger(test.class.getName()).log(Level.SEVERE, null, ex);
            }
        
        }
        
        
    }//GEN-LAST:event__searchButtonActionPerformed

    private void _selectButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event__selectButtonActionPerformed
        _idViewr=_textSelect.getText();
        System.out.println(_idViewr);
        _tableSchedule.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"
            }
        ));
        if(_idClient.equals("") && _comboJob.getSelectedIndex()==0){
            try{
        DefaultTableModel model = (DefaultTableModel) _tableScheduleAD.getModel();
        model.setRowCount(0);
        String t="SELECT s.roll_no,s.name_student, classes.class_id, c.subject_code, c.name_subject, c.credit, classes.room_number, classes.weekday, classes.time\n" +
"FROM Student s, Course c, Classes classes , Study study\n" +
"WHERE s.roll_no = study.roll_no AND study.class_id = classes.class_id AND classes.subject_code = c.subject_code AND s.roll_no='"+_idViewr+"'";
        ArrayList<ScheduleStudent> studentClasses = getScheduleStudentList(t);
        _tempStudentSchedule=studentClasses;
        Object[] row = new Object[4];
        for(int k=0;k<studentClasses.size();k++){
            row[0] = studentClasses.get(k).getClass_id();
            row[1] = studentClasses.get(k).getSubject_code();
            row[2] = studentClasses.get(k).getName_subject();
            row[3] = studentClasses.get(k).getCredit();
            model.addRow(row);
        }
            }catch(Exception e){
            
            }
        }
    }//GEN-LAST:event__selectButtonActionPerformed

    private void _scheduleButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event__scheduleButtonActionPerformed
        if(!_idViewr.equals("")){
            if(_comboJob.getSelectedIndex()==0){
                String text = "SELECT s.roll_no,s.name_student, A.Amount, A.deadline_date, A.paid_or_unpaid FROM Student s\n" +
"INNER JOIN (SELECT t.tuition_id,p.roll_no,p.Amount,t.deadline_date,t.paid_or_unpaid FROM Tuition t, Pay p WHERE t.tuition_id = p.tuition_id) AS A\n" +
"ON s.roll_no = A.roll_no and s.roll_no='"+_idViewr+"';";
            try {
                ArrayList<TuitionStudent> tuitionStudentlist=getTuitionStudentList(text);
                _textIDTable.setText(tuitionStudentlist.get(0).getRoll_no());
                _textNameTable.setText(tuitionStudentlist.get(0).getName_student());
                _textRoleTable.setText((String) _comboJob.getSelectedItem());
                System.out.println(tuitionStudentlist.get(0).paid_or_unpaid);
                if(tuitionStudentlist.get(0).paid_or_unpaid){
                DefaultTableModel model = (DefaultTableModel) _tableSchedule.getModel();
                String t="SELECT s.roll_no,s.name_student, classes.class_id, c.subject_code, c.name_subject, c.credit ,classes.room_number, classes.weekday, classes.time\n" +
"FROM Student s, Course c, Classes classes , Study study\n" +
"WHERE s.roll_no = study.roll_no AND study.class_id = classes.class_id AND classes.subject_code = c.subject_code AND s.roll_no='"+_idViewr+"'";
                ArrayList<ScheduleStudent> ss = getScheduleStudentList(t);
                
                _studentSchedule=ss;
                for(int i=0;i<ss.size();i++){
                    int c=ss.get(i).getColumm();
                    int r=ss.get(i).getRow();
                    for(int j=0;j<3;j++){
                        model.setValueAt(ss.get(i).getName_subject(),r+j,c);
                    }
                }
            
            //model.setValueAt("ngoc",3,0);
                
               
                }else{
                    JOptionPane.showMessageDialog(this,"Please pay your tuition fee to get more information");
                }
            } catch (SQLException ex) {
                Logger.getLogger(test.class.getName()).log(Level.SEVERE, null, ex);
            }
            }else{
                try{
                DefaultTableModel model = (DefaultTableModel) _tableSchedule.getModel();
                String t="SELECT s.id_staff,s.name_staff, classes.class_id, c.subject_code, c.name_subject, classes.room_number, classes.weekday, classes.time\n" +
"FROM Staff s, Course c, Classes classes , Teach t\n" +
"WHERE s.id_staff = t.id_staff AND t.class_id= classes.class_id AND classes.subject_code = c.subject_code \n" +
"AND s.id_staff = '"+_idViewr+"'";
                ArrayList<ScheduleStaff> ss = getScheduleStaffList(t);
                
                _staffSchedule=ss;
                _textIDTable.setText(_idViewr);
                _textNameTable.setText(ss.get(0).getName_staff());
                _textRoleTable.setText((String) _comboJob.getSelectedItem());
               
                for(int i=0;i<ss.size();i++){
                    int c=ss.get(i).getColumm();
                    int r=ss.get(i).getRow();
                    for(int j=0;j<3;j++){
                        model.setValueAt(ss.get(i).getName_subject(),r+j,c);
                    }
                }
                }catch(Exception e){
                    
                }
            }
            
        }else{
            if(!_idClient.equals("")){
                try{
            DefaultTableModel model = (DefaultTableModel) _tableSchedule.getModel();
                    
            if(student_OR_teacher){
                 String text = "SELECT s.roll_no,s.name_student, A.Amount, A.deadline_date, A.paid_or_unpaid FROM Student s\n" +
"INNER JOIN (SELECT t.tuition_id,p.roll_no,p.Amount,t.deadline_date,t.paid_or_unpaid FROM Tuition t, Pay p WHERE t.tuition_id = p.tuition_id) AS A\n" +
"ON s.roll_no = A.roll_no and s.roll_no='"+_idClient+"';";
            try {
                ArrayList<TuitionStudent> tuitionStudentlist=getTuitionStudentList(text);
                _textIDTable.setText(tuitionStudentlist.get(0).getRoll_no());
                _textNameTable.setText(tuitionStudentlist.get(0).getName_student());
                _textRoleTable.setText((String) _comboJob.getSelectedItem());
                if(tuitionStudentlist.get(0).paid_or_unpaid){
                
                String t="SELECT s.roll_no,s.name_student, classes.class_id, c.subject_code, c.name_subject,c.credit ,classes.room_number, classes.weekday, classes.time\n" +
"FROM Student s, Course c, Classes classes , Study study\n" +
"WHERE s.roll_no = study.roll_no AND study.class_id = classes.class_id AND classes.subject_code = c.subject_code AND s.roll_no='"+_idClient+"'";
                ArrayList<ScheduleStudent> ss = getScheduleStudentList(t);
                
                _studentSchedule=ss;
                for(int i=0;i<ss.size();i++){
                    int c=ss.get(i).getColumm();
                    int r=ss.get(i).getRow();
                    for(int j=0;j<3;j++){
                        model.setValueAt(ss.get(i).getName_subject(),r+j,c);
                    }
                }
            
            //model.setValueAt("ngoc",3,0);
                
               
                }else{
                    JOptionPane.showMessageDialog(this,"Please pay your tuition fee to get more information");
                }
            } catch (SQLException ex) {
                Logger.getLogger(test.class.getName()).log(Level.SEVERE, null, ex);
            }
            }else{
                String t="SELECT s.id_staff,s.name_staff, classes.class_id, c.subject_code, c.name_subject, classes.room_number, classes.weekday, classes.time\n" +
"FROM Staff s, Course c, Classes classes , Teach t \n" +
"WHERE s.id_staff = t.id_staff AND t.class_id= classes.class_id AND classes.subject_code = c.subject_code \n" +
"AND s.id_staff = '"+_idClient+"'";
                ArrayList<ScheduleStaff> ss = getScheduleStaffList(t);
                
                _staffSchedule=ss;
                _textIDTable.setText(_idClient);
                _textNameTable.setText(ss.get(0).getName_staff());
                _textRoleTable.setText("Teacher");
                
                for(int i=0;i<ss.size();i++){
                    int c=ss.get(i).getColumm();
                    int r=ss.get(i).getRow();
                    for(int j=0;j<3;j++){
                        model.setValueAt(ss.get(i).getName_subject(),r+j,c);
                    }
                }
            }
            }catch(Exception ex){
                
            }
            }
        }
    }//GEN-LAST:event__scheduleButtonActionPerformed

    private void _textSelectActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event__textSelectActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event__textSelectActionPerformed

    private void _tableInfoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__tableInfoMouseClicked
        int i = _tableInfo.getSelectedRow();
        TableModel model = _tableInfo.getModel();
        _textSelect.setText(model.getValueAt(i,0).toString());
    }//GEN-LAST:event__tableInfoMouseClicked

    private void _salaryButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event__salaryButtonActionPerformed
        if(!_idViewr.equals("")){
            String text = "SELECT id_staff, name_staff, salary FROM Staff WHERE id_staff = '"+_idViewr+"'";
            try {
                ArrayList<SalaryStaff> salaryStafflist=getSalaryStaffList(text);
                text="ID :  "+_idViewr+
                 "\n Name :  "+ salaryStafflist.get(0).getName()+
                 "\n Salary :  "+salaryStafflist.get(0).getSalary()+" VND"+
                 "\n----------------------------------------------------";
            JOptionPane.showMessageDialog(this,text);
            } catch (SQLException ex) {
                Logger.getLogger(test.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        }else{
            if(!_idClient.equals("")){
                String text = "SELECT id_staff, name_staff, salary FROM Staff WHERE id_staff = '"+_idClient+"'";
            try {
                ArrayList<SalaryStaff> salaryStafflist=getSalaryStaffList(text);
                text="ID :  "+_idClient+
                 "\n Name :  "+ salaryStafflist.get(0).getName()+
                 "\n Salary :  "+salaryStafflist.get(0).getSalary()+" VND"+
                 "\n----------------------------------------------------";
            JOptionPane.showMessageDialog(this,text);
            } catch (SQLException ex) {
                Logger.getLogger(test.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
        }
    }//GEN-LAST:event__salaryButtonActionPerformed

    private void _tuitionButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event__tuitionButtonActionPerformed
        if(!_idViewr.equals("")){
            String text = "SELECT s.roll_no,s.name_student, A.Amount, A.deadline_date, A.paid_or_unpaid FROM Student s\n" +
"INNER JOIN (SELECT t.tuition_id,p.roll_no,p.Amount,t.deadline_date,t.paid_or_unpaid FROM Tuition t, Pay p WHERE t.tuition_id = p.tuition_id) AS A\n" +
"ON s.roll_no = A.roll_no and s.roll_no='"+_idViewr+"';";
            try {
                ArrayList<TuitionStudent> tuitionStudentlist=getTuitionStudentList(text);
                
                String check;
                if(tuitionStudentlist.get(0).paid_or_unpaid){
                    check="Paid";
                }else{
                    check="Unpaid(Pay the fee to see your schedule)";
                }
                text="ID :  "+_idViewr+
                 "\n Name :  "+ tuitionStudentlist.get(0).getName_student()+
                 "\n Fee :  "+tuitionStudentlist.get(0).getAmount()+" VND"+
                 "\n Deadline :  "+tuitionStudentlist.get(0).getDeadline()+
                 "\n Status :  "+ check +
                 "\n----------------------------------------------------";
            JOptionPane.showMessageDialog(this,text);
            } catch (SQLException ex) {
                Logger.getLogger(test.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        }else{
            if(!_idClient.equals("")){
                String text = "SELECT s.roll_no,s.name_student, A.Amount, A.deadline_date, A.paid_or_unpaid FROM Student s\n" +
"INNER JOIN (SELECT t.tuition_id,p.roll_no,p.Amount,t.deadline_date,t.paid_or_unpaid FROM Tuition t, Pay p WHERE t.tuition_id = p.tuition_id) AS A\n" +
"ON s.roll_no = A.roll_no and s.roll_no='"+_idClient+"';";
            try {
                ArrayList<TuitionStudent> tuitionStudentlist=getTuitionStudentList(text);
                
                String check;
                if(tuitionStudentlist.get(0).paid_or_unpaid){
                    check="Paid";
                }else{
                    check="Unpaid(Pay the fee to see your schedule)";
                }
                text="ID :  "+_idClient+
                 "\n Name :  "+ tuitionStudentlist.get(0).getName_student()+
                 "\n Fee :  "+tuitionStudentlist.get(0).getAmount()+" VND"+
                 "\n Deadline :  "+tuitionStudentlist.get(0).getDeadline()+
                 "\n Status :  "+ check +
                 "\n----------------------------------------------------";
            JOptionPane.showMessageDialog(this,text);
            } catch (SQLException ex) {
                Logger.getLogger(test.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
        }
    }//GEN-LAST:event__tuitionButtonActionPerformed

    private void _tableScheduleMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__tableScheduleMouseClicked
        int i = _tableSchedule.getSelectedRow();
        int j = _tableSchedule.getSelectedColumn();
        TableModel model = _tableSchedule.getModel();
        if(model.getValueAt(i,j)!=null){
            String infoClass= model.getValueAt(i,j).toString();
            if(_idViewr.equals("")){
                if(student_OR_teacher){
                    for(int k=0;k<_studentSchedule.size();k++){
                        if(_studentSchedule.get(k).getName_subject().equals(infoClass)){
                            String t ="ID subject: "+_studentSchedule.get(k).getSubject_code()
                                  +"\n Name subject: "+_studentSchedule.get(k).getName_subject()
                                  +"\n Credit: "+_studentSchedule.get(k).getCredit()
                                  +"\n Room: "+_studentSchedule.get(k).getRoom_number()
                                  +"\n Day: "+_studentSchedule.get(k).getWeekday()
                                  +"\n Time: "+_studentSchedule.get(k).getTime();
                            JOptionPane.showMessageDialog(null, t);
                            break;
                        }
                    }
                }else{
                    for(int k=0;k<_staffSchedule.size();k++){
                       if(_staffSchedule.get(k).getName_subject().equals(infoClass)){
                            String t ="ID subject: "+_staffSchedule.get(k).getSubject_code()
                                  +"\n Name subject: "+_staffSchedule.get(k).getName_subject()
                                  +"\n Credit: "+_staffSchedule.get(k).getCredit()
                                  +"\n Room: "+_staffSchedule.get(k).getRoom_number()
                                  +"\n Day: "+_staffSchedule.get(k).getWeekday()
                                  +"\n Time: "+_staffSchedule.get(k).getTime();
                            JOptionPane.showMessageDialog(null, t);
                            break;
                        }
                    }
                }
            }else{
                if(_comboJob.getSelectedIndex()==0){
                    for(int k=0;k<_studentSchedule.size();k++){
                        if(_studentSchedule.get(k).getName_subject().equals(infoClass)){
                            String t ="ID subject: "+_studentSchedule.get(k).getSubject_code()
                                  +"\n Name subject: "+_studentSchedule.get(k).getName_subject()
                                  +"\n Credit: "+_studentSchedule.get(k).getCredit()
                                  +"\n Room: "+_studentSchedule.get(k).getRoom_number()
                                  +"\n Day: "+_studentSchedule.get(k).getWeekday()
                                  +"\n Time: "+_studentSchedule.get(k).getTime();
                            JOptionPane.showMessageDialog(null, t);
                            break;
                        }
                    }
                }else{
                    for(int k=0;k<_staffSchedule.size();k++){
                       if(_staffSchedule.get(k).getName_subject().equals(infoClass)){
                            String t ="ID subject: "+_staffSchedule.get(k).getSubject_code()
                                  +"\n Name subject: "+_staffSchedule.get(k).getName_subject()
                                  +"\n Credit: "+_staffSchedule.get(k).getCredit()
                                  +"\n Room: "+_staffSchedule.get(k).getRoom_number()
                                  +"\n Day: "+_staffSchedule.get(k).getWeekday()
                                  +"\n Time: "+_staffSchedule.get(k).getTime();
                            JOptionPane.showMessageDialog(null, t);
                            break;
                        }
                    }
                }
                
            }
        }
        
    }//GEN-LAST:event__tableScheduleMouseClicked

    private void _tSexActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event__tSexActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event__tSexActionPerformed

    private void _tMajorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event__tMajorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event__tMajorActionPerformed

    private void _imageButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event__imageButtonActionPerformed
        JFileChooser chooser = new JFileChooser();
        chooser.showOpenDialog(null);
        File f = chooser.getSelectedFile();
        filename= f.getAbsolutePath();
        System.out.println(filename);
        ImageIcon imageIcon = new ImageIcon(new ImageIcon(filename).getImage().getScaledInstance(_labelImage.getWidth(), _labelImage.getHeight(), Image.SCALE_SMOOTH));
        _labelImage.setIcon(imageIcon);
    }//GEN-LAST:event__imageButtonActionPerformed

    private void _tableScheduleMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__tableScheduleMouseEntered
        
    }//GEN-LAST:event__tableScheduleMouseEntered
    private String getSubjectMajor(int index){
        if(index==1){
            return "BA";
        }else if(index==2){
            return "BT";
        }else if(index==3){
            return "IT";
        }else if(index==4){
            return "EE";
        }else if(index==5){
            return "CE";
        }else if(index==6){
            return "ISE";
        }
        else{
            return "MA";
        }
    }
    private void _filterButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event__filterButtonActionPerformed
        if(!_idClient.equals("") && student_OR_teacher || _idClient.equals("")){
        DefaultTableModel model = (DefaultTableModel) _tableClassesAD.getModel();
        model.setRowCount(0);
        try{
            System.out.println(getSubjectMajor(_comboNameMajorAD.getSelectedIndex()));
        String add ="";
        String[] addArray = new String[10]; 
        int count=0;
        if(_comboNameMajorAD.getSelectedIndex()!=0){
           addArray[count]="c.subject_code like '%"+getSubjectMajor(_comboNameMajorAD.getSelectedIndex())+"%' ";
           count++;
            
        }
        if(!_textNameSubjectAD.getText().equals("")){
           addArray[count]="name_subject like '%"+_textNameSubjectAD.getText()+"%'";
           count++;
        }
        for(int i=0;i<count;i++){
            add+=" and "+addArray[i];
        }
           
        ArrayList<ListofClasses> list = getClassSystemList(add);
        Object[] row = new Object[8];
        for(int i=0;i<list.size();i++){
            row[0] = list.get(i).getClassID();
            row[1] = list.get(i).getSubjectCode();
            row[2] = list.get(i).getNameSubject();
            row[3] = list.get(i).getCredit();
            row[4] = list.get(i).getWeekday();
            row[5] = list.get(i).getTime();
            row[6] = list.get(i).getRoom();
            row[7] = list.get(i).getStaffName();
            model.addRow(row);
        }
        }catch(Exception e){
            
        }
        }
        
    }//GEN-LAST:event__filterButtonActionPerformed

    private void _tableClassesADMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__tableClassesADMouseClicked
       int i = _tableClassesAD.getSelectedRow();
       TableModel model = _tableClassesAD.getModel();
       tempTime=model.getValueAt(i,5).toString();
       tempDay=model.getValueAt(i,4).toString();
       tempClassId=model.getValueAt(i,0).toString();
        
    }//GEN-LAST:event__tableClassesADMouseClicked

    private void _addADButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event__addADButtonActionPerformed
        if(tempTime.equals("") || tempClassId.equals("") || tempDay.equals("")){
            JOptionPane.showMessageDialog(null,"Show full info to add subject");
            return;
        }else{
            try {
                if(_idClient.equals("")){
                    if(!_idViewr.equals("") && _comboJob.getSelectedIndex()==0)  show_schedule_table_for_student(tempDay, tempTime, tempClassId,"addSubject",_idViewr);
                }else{
                    if(student_OR_teacher) show_schedule_table_for_student(tempDay, tempTime, tempClassId,"addSubject",_idClient);
                }
                tempDay="";tempTime="";tempClassId="";
            } catch (SQLException ex) {
                Logger.getLogger(test.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event__addADButtonActionPerformed

    private void _tableScheduleADMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__tableScheduleADMouseClicked
       int i = _tableScheduleAD.getSelectedRow();
       TableModel model = _tableScheduleAD.getModel();
       tempClassIdDrop=model.getValueAt(i,0).toString();
        System.out.println(tempClassIdDrop);
    }//GEN-LAST:event__tableScheduleADMouseClicked

    private void _dropADButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event__dropADButtonActionPerformed
        if(tempClassIdDrop.equals("")){
            JOptionPane.showMessageDialog(null,"Show full info to drop subject");
            return;
        }else{
            try {
                if(_idClient.equals("")){
                    if(!_idViewr.equals("") && _comboJob.getSelectedIndex()==0 )  show_schedule_table_for_student("", "", tempClassIdDrop,"dropSubject",_idViewr);
                }else{
                    if(student_OR_teacher) show_schedule_table_for_student("", "", tempClassIdDrop,"dropSubject",_idClient);
                }
                tempClassIdDrop="";
            } catch (SQLException ex) {
                Logger.getLogger(test.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event__dropADButtonActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        if(_textUserNameInfo.getText().equals(_tUsername.getText()) && _textPasswordInfo.getText().equals(_tPassword.getText())){
            try{
                String text ="UPDATE Account SET  username="+_textUserNameInfo.getText()+",password="+_textNewPasswordInfo.getText()+" username= '"+_textUserNameInfo.getText()+"' and password='"+_textPasswordInfo+"'";
                executeSQLquery(text,"Update");
            }catch(Exception e){
                
            }
        }else{
            JOptionPane.showMessageDialog(null, "Your username or password incorrect");
            return;
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void _clearADButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event__clearADButtonActionPerformed
        _textNameSubjectAD.setText("");
        _comboNameMajorAD.setSelectedIndex(0);
        
        _tableClassesAD.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Class ID", "Subject Code", "Name Subject", "Credit", "Weekday", "Time", "Room ", "Staff name"
            }
        ));
        
        
    }//GEN-LAST:event__clearADButtonActionPerformed

    private void _comboTablesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event__comboTablesActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event__comboTablesActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(test.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(test.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(test.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(test.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new test().setVisible(true);
                    //new test("BA1","billgate").setVisible(true);
                    //new test("BABAIU15234","baiu15234").setVisible(true);
                } catch (SQLException ex) {
                    Logger.getLogger(test.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton _addADButton;
    private javax.swing.JTabbedPane _adminPanel;
    private javax.swing.JButton _clearADButton;
    private javax.swing.JButton _clearButoon;
    private javax.swing.JComboBox<String> _comboJob;
    private javax.swing.JComboBox<String> _comboMajor;
    private javax.swing.JComboBox<String> _comboNameMajorAD;
    private javax.swing.JComboBox<String> _comboSection;
    private javax.swing.JComboBox<String> _comboSex;
    private javax.swing.JComboBox<String> _comboTables;
    private javax.swing.JButton _dropADButton;
    private javax.swing.JButton _filterButton;
    private javax.swing.JButton _imageButton;
    private javax.swing.JLabel _labelImage;
    private javax.swing.JButton _salaryButton;
    private javax.swing.JLabel _salaryMajorLB;
    private javax.swing.JButton _scheduleButton;
    private javax.swing.JButton _searchButton;
    private javax.swing.JLabel _sectionLB;
    private javax.swing.JButton _selectButton;
    private javax.swing.JButton _selectTableButton;
    private javax.swing.JTextField _tID;
    private javax.swing.JTextField _tMajor;
    private javax.swing.JTextField _tName;
    private javax.swing.JPasswordField _tPassword;
    private javax.swing.JTextField _tRole;
    private javax.swing.JTextField _tSection;
    private javax.swing.JTextField _tSex;
    private javax.swing.JTextField _tUsername;
    private javax.swing.JTable _tableClassesAD;
    private javax.swing.JTable _tableInfo;
    private javax.swing.JTable _tableSchedule;
    private javax.swing.JTable _tableScheduleAD;
    private javax.swing.JTextArea _textArea;
    private javax.swing.JTextField _textIDTable;
    private javax.swing.JTextField _textName;
    private javax.swing.JTextField _textNameSubjectAD;
    private javax.swing.JTextField _textNameTable;
    private javax.swing.JPasswordField _textNewPasswordInfo;
    private javax.swing.JPasswordField _textPasswordInfo;
    private javax.swing.JTextField _textRoleTable;
    private javax.swing.JTextField _textSelect;
    private javax.swing.JTextField _textUserNameInfo;
    private javax.swing.JButton _tuitionButton;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private java.awt.Panel panel1;
    private java.awt.Panel panel2;
    // End of variables declaration//GEN-END:variables
}

