/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TableObject;

/**
 *
 * @author TripleB
 */
public class ListofClasses {
    public String _classID,_subjectCode,_nameSubject,_weekday,_time,_room,_staffName;
    public int credit;

    public ListofClasses(String _classID, String _subjectCode, String _nameSubject,int credit ,String _weekday, String _time, String _room, String _staffName ) {
        this._classID = _classID;
        this._subjectCode = _subjectCode;
        this._nameSubject = _nameSubject;
        this._weekday = _weekday;
        this._time = _time;
        this._room = _room;
        this._staffName = _staffName;
        this.credit = credit;
    }

    public String getClassID() {
        return _classID;
    }

    public void setClassID(String _classID) {
        this._classID = _classID;
    }

    public String getSubjectCode() {
        return _subjectCode;
    }

    public void setSubjectCode(String _subjectCode) {
        this._subjectCode = _subjectCode;
    }

    public String getNameSubject() {
        return _nameSubject;
    }

    public void setNameSubject(String _nameSubject) {
        this._nameSubject = _nameSubject;
    }

    public String getWeekday() {
        return _weekday;
    }

    public void setWeekday(String _weekday) {
        this._weekday = _weekday;
    }

    public String getTime() {
        return _time;
    }

    public void setTime(String _time) {
        this._time = _time;
    }

    public String getRoom() {
        return _room;
    }

    public void setRoom(String _room) {
        this._room = _room;
    }

    public String getStaffName() {
        return _staffName;
    }

    public void setStaffName(String _staffName) {
        this._staffName = _staffName;
    }

    public int getCredit() {
        return credit;
    }

    public void setCredit(int credit) {
        this.credit = credit;
    }
    
}
