/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TableObject;

/**
 *
 * @author TripleB
 */
public class SalaryStaff {
    String _id,_name;
    int _salary;
    
    public SalaryStaff(String _id,String _name,int _salary){
        this._id=_id;
        this._name=_name;
        this._salary=_salary;
    }

    public String getId() {
        return _id;
    }

    public void setId(String _id) {
        this._id = _id;
    }

    public String getName() {
        return _name;
    }

    public void setName(String _name) {
        this._name = _name;
    }

    public int getSalary() {
        return _salary;
    }

    public void setSalary(int _salary) {
        this._salary = _salary;
    }

   
    
}
