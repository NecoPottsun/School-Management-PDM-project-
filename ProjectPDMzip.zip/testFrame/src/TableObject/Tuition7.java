/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TableObject;

import java.sql.Date;

/**
 *
 * @author TripleB
 */
public class Tuition7 {
    public int tuition_id;
    public Date deadline;
    public int paid_or_unpaid;
    public Tuition7(int tuition_id,int paid_or_unpaid,Date deadline){
        this.tuition_id=tuition_id;
        this.paid_or_unpaid=paid_or_unpaid;
        this.deadline=deadline;
    }

    public Date getDeadline() {
        return deadline;
    }

    public void setDeadline(Date deadline) {
        this.deadline = deadline;
    }

    public int getTuition_id() {
        return tuition_id;
    }

    public void setTuition_id(int tuition_id) {
        this.tuition_id = tuition_id;
    }

    

    public int getPaid_or_unpaid() {
        return paid_or_unpaid;
    }

    public void setPaid_or_unpaid(int paid_or_unpaid) {
        this.paid_or_unpaid = paid_or_unpaid;
    }
}
